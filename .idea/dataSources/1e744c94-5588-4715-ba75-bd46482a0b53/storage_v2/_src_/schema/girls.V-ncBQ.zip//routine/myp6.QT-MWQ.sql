create
    definer = root@localhost procedure myp6(IN beautyName varchar(20), OUT boyName varchar(20))
BEGIN
SELECT bo.boyname INTO boyname
FROM boys bo
RIGHT JOIN
beauty b ON b.boyfriend_id = bo.id
WHERE b.name=beautyName ;

END;

