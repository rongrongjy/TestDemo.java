create
    definer = root@localhost procedure pro1()
begin
insert into admin(username,`password`)
values('john','0000'),('tom','5462');
end;

