create
    definer = root@localhost procedure myp7(IN beautyName varchar(20), OUT boyName varchar(20), OUT usercp int)
BEGIN
SELECT boys.boyname ,boys.usercp INTO boyname,usercp
FROM boys 
RIGHT JOIN
beauty b ON b.boyfriend_id = boys.id
WHERE b.name=beautyName ;

END;

