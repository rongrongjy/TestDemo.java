create
    definer = root@localhost procedure pro6(INOUT a int, INOUT b int)
begin
set a = a*2;
set b= b*2;
end;

