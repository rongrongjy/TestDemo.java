create
    definer = root@localhost procedure pro2(IN beautyName varchar(20))
begin 
select bo.*
from boys bo
right join beauty b 
on bo.id = b.boyFriend_id
where b.name = beautyName;
end;

