create
    definer = root@localhost procedure pro5(IN username varchar(20), IN lopassword varchar(20))
begin
insert into admin(admin.username,password)
value(username,lopassword);
end;

